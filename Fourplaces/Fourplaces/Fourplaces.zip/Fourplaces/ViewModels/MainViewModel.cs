﻿using Fourplaces.Modele;
using Fourplaces.Views;
using Storm.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace Fourplaces.ViewModels
{
    class MainViewModel : ViewModelBase
    {
        //private DataTemplate dt;
        private ObservableCollection<ItemModel> _TaskItems;
        public ObservableCollection<ItemModel> TaskItems
        {
            get
            {
                return _TaskItems;

            }
            set
            {
                SetProperty(ref _TaskItems, value);
                Console.WriteLine("BONJOUR JE SUIS LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            }
        }

        //public DataTemplate Dt { get => dt; set => SetProperty(ref dt, value); }

        public MainViewModel()
        {
            //Console.WriteLine("BONJOUR JE SUIS LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            TaskItems = new ObservableCollection<ItemModel>();
            TaskItems.Add(new ItemModel { Nom = "lieu 1" });
            TaskItems.Add(new ItemModel { Nom = "lieu 2" });
            TaskItems.Add(new ItemModel { Nom = "lieu 3" });
            //Dt = new DataTemplate(typeof(CustomCell));
        }

        /*private ObservableCollection<ItemModel> _listOfItems = new ObservableCollection<ItemModel>() { new ItemModel("lieu 1") , new ItemModel("lieu 2") };

        public ObservableCollection<ItemModel> ListOfItems
        {
            get
            {
                return _listOfItems;
            }
            set
            {
                SetProperty(ref _listOfItems, value);
            }
        }*/
    }
}
