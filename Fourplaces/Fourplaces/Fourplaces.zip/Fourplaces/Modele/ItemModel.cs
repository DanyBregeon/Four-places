﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fourplaces.Modele
{
    class ItemModel
    {
        private string _nom;

        /*public ItemModel(string nom)
        {
            Nom = nom;
        }*/

        public string Nom { get => _nom; set => _nom = value; }


    }
}
